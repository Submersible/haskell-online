#!/usr/bin/env sh

cat > code.tar
tar xfv code.tar > /dev/null
runghc Main.hs