main :: IO ()
main = putStrLn "hello world"
